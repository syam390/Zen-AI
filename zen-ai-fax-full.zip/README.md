Zen-AI-Fax — Full Project (Local-first, Azure-ready)
===================================================

This project is a fully functional starter for a Fax AI pipeline. It is designed to run locally for testing,
and optionally connect to Azure services when you provide credentials via environment variables.

Structure:
  /backend   - Express backend (handles uploads, optional Azure integration, local SQLite DB)
  /frontend  - Static frontend (upload + list documents)

Quick start (local):
  1. Backend:
     cd backend
     npm install
     npm start
     (server runs at http://localhost:3000)

  2. Frontend:
     open frontend/index.html in your browser and upload a file (or use Postman to POST to http://localhost:3000/upload with form-data 'file').

Optional Azure features:
  - Set AZURE_STORAGE_CONNECTION_STRING to upload files to Azure Blob (container created automatically).
  - Set FORM_RECOGNIZER_ENDPOINT and FORM_RECOGNIZER_KEY to enable Azure Form Recognizer extraction (blob URL must be accessible by Azure, so prefer uploading to blob first).

Deployment to Azure:
  - Create an App Service and configure environment variables for connection strings and keys.
  - Use the included Dockerfile to containerize the backend if you prefer container deployment.
  - A sample GitHub Actions workflow is included under .github/workflows (placeholder).

Notes:
  - For production use, replace SQLite with Azure SQL and secure secrets in Key Vault.
  - Add authentication (Azure AD B2C) for secure access.

const path = require('path');
const fs = require('fs');

// If azure env vars are provided, use Azure Form Recognizer
const useAzure = process.env.FORM_RECOGNIZER_ENDPOINT && process.env.FORM_RECOGNIZER_KEY;

let azureClient = null;
if (useAzure) {
  const { DocumentAnalysisClient, AzureKeyCredential } = require('@azure/ai-form-recognizer');
  azureClient = new DocumentAnalysisClient(process.env.FORM_RECOGNIZER_ENDPOINT, new AzureKeyCredential(process.env.FORM_RECOGNIZER_KEY));
}

async function analyze(blobUrl, localPath) {
  if (useAzure && azureClient) {
    try {
      // Azure can analyze from URL; if blobUrl is local path, you'd need to upload first.
      // Here we support blobUrl being an HTTP(s) URL to blob storage.
      console.log('Using Azure Form Recognizer for', blobUrl);
      const poller = await azureClient.beginAnalyzeDocument('prebuilt-document', blobUrl);
      const result = await poller.pollUntilDone();
      const fields = [];
      // extract key-value pairs
      if (result && result.keyValuePairs) {
        for (const kv of result.keyValuePairs) {
          const key = kv.key?.content || null;
          const val = kv.value?.content || null;
          if (key) fields.push({ name: key, value: val, confidence: kv.value?.confidence || 0.0 });
        }
      }
      // fallback: search for recognized form fields
      if (result && result.pages) {
        // nothing extra for now
      }
      return { fields, documentType: 'unknown', confidence: 0.0 };
    } catch (err) {
      console.error('Azure analyze failed', err);
      // fallback to mock below
    }
  }

  // Simple mock analyzer using filename heuristics and (optionally) reading local text if it's a .txt
  const filename = path.basename(localPath || blobUrl || '').toLowerCase();
  const fields = [];
  if (filename.includes('referral')) {
    fields.push({ name: 'document_type', value: 'referral', confidence: 0.95 });
    fields.push({ name: 'patient_name', value: 'John Doe', confidence: 0.9 });
    fields.push({ name: 'dob', value: '1980-01-01', confidence: 0.88 });
  } else if (filename.includes('prescription') || filename.includes('rx')) {
    fields.push({ name: 'document_type', value: 'prescription', confidence: 0.96 });
    fields.push({ name: 'patient_name', value: 'Jane Smith', confidence: 0.9 });
  } else {
    fields.push({ name: 'document_type', value: 'unknown', confidence: 0.5 });
    fields.push({ name: 'patient_name', value: 'Unknown', confidence: 0.3 });
  }

  return { fields, documentType: fields.find(f => f.name === 'document_type')?.value || 'unknown', confidence: fields.find(f => f.name === 'document_type')?.confidence || 0.0 };
}

module.exports = { analyze };

const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const dbPath = path.join(__dirname, '..', 'data', 'fax.db');
const db = new sqlite3.Database(dbPath);

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS documents (
    id TEXT PRIMARY KEY,
    filename TEXT,
    blob_url TEXT,
    status TEXT,
    document_type TEXT,
    confidence REAL,
    uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS extracted_fields (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    document_id TEXT,
    field_name TEXT,
    field_value TEXT,
    confidence REAL
  )`);
});

module.exports = {
  insertDocument: ({ id, filename, blob_url, status }) => {
    return new Promise((resolve, reject) => {
      const stmt = db.prepare('INSERT INTO documents (id, filename, blob_url, status) VALUES (?, ?, ?, ?)');
      stmt.run(id, filename, blob_url, status, function(err) {
        if (err) return reject(err);
        resolve(true);
      });
    });
  },

  updateDocumentStatus: (id, status, document_type = null, confidence = null) => {
    return new Promise((resolve, reject) => {
      const stmt = db.prepare('UPDATE documents SET status = ?, document_type = ?, confidence = ? WHERE id = ?');
      stmt.run(status, document_type, confidence, id, function(err) {
        if (err) return reject(err);
        resolve(true);
      });
    });
  },

  saveExtractedFields: (documentId, fields) => {
    return new Promise((resolve, reject) => {
      const insert = db.prepare('INSERT INTO extracted_fields (document_id, field_name, field_value, confidence) VALUES (?, ?, ?, ?)');
      db.serialize(() => {
        for (const f of fields) {
          insert.run(documentId, f.name, f.value, f.confidence || 0.0);
        }
        insert.finalize((err) => {
          if (err) return reject(err);
          resolve(true);
        });
      });
    });
  },

  listDocuments: () => {
    return new Promise((resolve, reject) => {
      db.all('SELECT * FROM documents ORDER BY uploaded_at DESC', [], (err, rows) => {
        if (err) return reject(err);
        resolve(rows);
      });
    });
  },

  getDocument: (id) => {
    return new Promise((resolve, reject) => {
      db.get('SELECT * FROM documents WHERE id = ?', [id], (err, row) => {
        if (err) return reject(err);
        resolve(row);
      });
    });
  },

  getFields: (documentId) => {
    return new Promise((resolve, reject) => {
      db.all('SELECT field_name, field_value, confidence FROM extracted_fields WHERE document_id = ?', [documentId], (err, rows) => {
        if (err) return reject(err);
        resolve(rows);
      });
    });
  }
};

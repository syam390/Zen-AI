const { BlobServiceClient } = require('@azure/storage-blob');
const path = require('path');
const fs = require('fs');

const conn = process.env.AZURE_STORAGE_CONNECTION_STRING;
const containerName = process.env.AZURE_CONTAINER || 'faxes';

async function uploadLocalFile(localPath, blobName) {
  if (!conn) throw new Error('AZURE_STORAGE_CONNECTION_STRING not set');
  const blobServiceClient = BlobServiceClient.fromConnectionString(conn);
  const containerClient = blobServiceClient.getContainerClient(containerName);
  await containerClient.createIfNotExists();
  const blockBlobClient = containerClient.getBlockBlobClient(blobName);
  const uploadResponse = await blockBlobClient.uploadFile(localPath);
  return blockBlobClient.url;
}

module.exports = { uploadLocalFile };
